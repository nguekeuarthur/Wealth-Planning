const mongoose = require("mongoose");

const todoSchema = new mongoose.Schema({
    text: { type: String, required: true },
    completed: { type: Boolean, default: false },
});

const taskSchema = new mongoose.Schema(
    {
        title: { type: String, required: true },
        description: { type: String },
        priority: { type: String, enum: ["Low", "Medium", "High", "Urgent"], default: "Medium" },
        status: { type: String, enum: ["Pending", "In Progress", "Completed"], default: "Pending" },
        dueDate: { type: Date, required: true },
        assignedTo: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
        assignedRoles: [{
            type: String,
            enum: ['admin', 'partner', 'collaborator', 'client']
        }],
        createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
        attachments: [{ type: String }],
        todoChecklist: [todoSchema], 
        progress: { type: Number, default: 0 },
        client: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
        project: { type: mongoose.Schema.Types.ObjectId, ref: "Project" }
        
    },
    { timestamps: true }
);

module.exports = mongoose.model("Task", taskSchema);
